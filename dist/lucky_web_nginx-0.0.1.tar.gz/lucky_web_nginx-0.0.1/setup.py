#!/usr/bin/env python3.6
# coding: utf-8
#setup.PY
# Created on 2017/12/30
# @author: zhaoyun
"""
description:

"""
from distutils.core import setup

setup(name="lucky_web_nginx",
      version="0.0.1",
      description="Python wsgi router web Fmwork",
      author="zilong",
      author_email="zhaoyun4240@163.com",
      url="https://github.com/zhaowenjun333/basic",
      packages=["luckynginx"])
